// Наследуем Rect от Square? Или Square от Rect? или...

class Rect {
public:
    void setWidth(double);
    void setHeight(double);
    //...
};

class Square {
public:
    void setArea(double);
    //...
};

int main() {}